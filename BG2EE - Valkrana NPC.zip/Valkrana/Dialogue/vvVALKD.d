// Dream Script
BEGIN vvVALKD